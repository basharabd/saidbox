<?php

use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\AdminWallteController;
use App\Http\Controllers\Api\BranchController;
use App\Http\Controllers\Api\CaptainController;
use App\Http\Controllers\Api\CaptainWallteController;
use App\Http\Controllers\Api\CityController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OrderStatusController;
use App\Http\Controllers\Api\RangController;
use App\Http\Controllers\Api\ReasonController;
use App\Http\Controllers\Api\SizeController;
use App\Http\Controllers\Api\StoreController;
use App\Http\Controllers\Api\StoreTypeController;
use App\Http\Controllers\Api\StoreWallteController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('auth:captain')->group(function () {
    //Captains
    Route::post('/captain/logout', [CaptainController::class, 'logout']);
});



Route::get('getOrderstatus' , [OrderStatusController::class , 'getOrderTrackingStatus']);
//Admin wallet
Route::get('/admin/wallet', [AdminWallteController::class,'index']);

//Captain wallet
Route::get('/captain/wallet', [CaptainWallteController::class,'index']);

//Captain wallet
Route::get('/store/wallet', [StoreWallteController::class,'index']);

// Admin
Route::post('signin/admin', [AdminController::class, 'login']);
Route::post('signup/admin', [AdminController::class,'signup']);
Route::post('verify/admin', [AdminController::class, 'verify']);
Route::post('resend-code/admin', [AdminController::class, 'resendCode']);
Route::get('one/admin/{id}', [AdminController::class,'getAdmin']);
Route::get('admins', [AdminController::class,'index']);
//Route::put('/update/admin/{id}', [AdminController::class, 'update']);
Route::post('/update/admin/{id}', [AdminController::class, 'adminUpdate']);
Route::post('/destroy/admin/{id}', [AdminController::class, 'destroy']);

//Route::delete('/destroy/admin/{id}', [AdminController::class, 'destroy']);

//Stores
Route::post('signin/store', [StoreController::class, 'login']);
Route::post('signup/store', [StoreController::class,'signup']);
Route::post('resend-code/store', [StoreController::class, 'resend_code']);
Route::post('verify/store', [StoreController::class, 'verify']);
Route::post('/logout/store', [StoreController::class, 'logout']);
Route::get('one/store/{id}', [StoreController::class,'getStore']);
Route::get('stores', [StoreController::class,'index']);
Route::post('/update/store/{id}', [StoreController::class, 'update']);
Route::post('/delete/store/{id}', [StoreController::class, 'destroy']);

//Route::put('/update/store/{id}', [StoreController::class, 'update']);
//Route::delete('/destroy/store/{id}', [StoreController::class, 'destroy']);
Route::get('/stores/{storeId}/orders', [StoreController::class , 'getOrdersByStore']);
Route::post('/stores/{id}/update-image', [StoreController::class, 'updateImage']);




//Captain

Route::post('signin/captain', [CaptainController::class, 'login']);
Route::post('signup/captain', [CaptainController::class,'signup']);
Route::post('verify/captain', [CaptainController::class, 'verify']);
Route::post('resend-code/captain', [CaptainController::class, 'resendCode']);
Route::get('one/captain/{id}', [CaptainController::class,'getCaptain']);
Route::get('captains', [CaptainController::class,'index']);
//Route::put('/update/captain/{id}', [CaptainController::class, 'update']);
Route::post('/update/captain/{id}', [CaptainController::class, 'update']);
Route::post('/destroy/captain/{id}', [CaptainController::class, 'destroy']);
//Route::delete('/destroy/captain/{id}', [CaptainController::class, 'destroy']);



Route::middleware('auth:store')->group(function () {
    //Stores
    Route::post('/store/logout', [StoreController::class, 'logout']);
    //Orders

    Route::get('getOrders' , [OrderController::class , 'getOrders']);
    Route::post('storeOrder', [OrderController::class,'storeOrder']);
    Route::post('/orders/cancel', [OrderController::class,'canceledOrder']);
    Route::get('order/{orderId}', [OrderController::class, 'getOrder']);
//    Route::put('/orders/{order}', [OrderController::class, 'updateOrderStatus']);
    Route::post('/orders/{order}/update-status', [OrderController::class, 'updateOrderStatus']);

});

Route::middleware('auth:admin')->group(function () {
    //Admins
    Route::post('/admin/logout', [AdminController::class, 'logout']);


});


//order_statuses

//Route::apiResource('order_statuses', OrderStatusController::class);

Route::get('/order-status/tracking', [OrderStatusController::class, 'getOrderTrackingStatus']);

// Routes for CRUD operations on order statuses
Route::get('/order-status', [OrderStatusController::class, 'index']);
Route::post('/order-status', [OrderStatusController::class, 'store']);
Route::get('/order-status/{orderStatus}', [OrderStatusController::class, 'show']);
//Route::put('/order-status/{orderStatus}', [OrderStatusController::class, 'update']);
Route::post('/order-status/{orderStatus}/update', [OrderStatusController::class, 'update']);

//Route::delete('/order-status/{orderStatus}', [OrderStatusController::class, 'destroy']);
Route::post('/order-status/{orderStatus}/delete', [OrderStatusController::class, 'destroy']);


//store-types
    //Route::apiResource('store-types' , StoreTypeController::class);
    Route::get('/store-types', [StoreTypeController::class, 'index']);
    Route::post('/store-types', [StoreTypeController::class, 'store']);
    Route::get('/store-types/{id}', [StoreTypeController::class, 'show']);
   // Route::put('/store-types/{id}', [StoreTypeController::class, 'update']);
    Route::post('/store-types/{id}/update', [StoreTypeController::class, 'update']);
    Route::post('/store-types/{id}/delete', [StoreTypeController::class, 'destroy']);

    //Route::delete('/store-types/{id}', [StoreTypeController::class, 'destroy']);

//reasons
  //  Route::apiResource('reasons', ReasonController::class);
    Route::get('/reasons', [ReasonController::class, 'index']);
    Route::post('/reasons', [ReasonController::class, 'store']);
    Route::get('/reasons/{reason}', [ReasonController::class, 'show']);
   // Route::put('/reasons/{reason}', [ReasonController::class, 'update']);
    Route::post('/reasons/{reason}', [ReasonController::class, 'update']);

   Route::post('/reasons/{reason}/destroy', [ReasonController::class, 'destroy']);




//Sizes

    Route::get('/get/one/size/{sizeId}' , [SizeController::class , 'getsize']);
    Route::get('/get/size', [SizeController::class, 'sizes']);
    Route::post('/create/size', [SizeController::class,'storeSize']);
  //  Route::put('/update/size/{id}', [SizeController::class, 'updateSize']);
     Route::post('/update/size/{id}', [SizeController::class, 'updateSize']);
     Route::post('/delete/size/{id}', [SizeController::class, 'destroy']);

//Route::delete('/delete/size/{id}', [SizeController::class,'destroy']);


//Cities
    Route::get('/get/one/city/{cityId}' , [CityController::class , 'getcity']);
    Route::get('/get/city', [CityController::class, 'cities']);
    Route::post('/create/city', [CityController::class,'storeCity']);
//    Route::put('/update/city/{id}', [CityController::class, 'updateCity']);
Route::post('/update/city/{id}', [CityController::class, 'updateCity']);

//    Route::delete('/delete/city/{id}', [CityController::class,'destroy']);
Route::post('/delete/city/{id}', [CityController::class, 'destroy']);


//Rang
    Route::get('one/rang/{id}', [RangController::class,'getRang']);
    Route::get('rangs', [RangController::class, 'index']);
    Route::get('rangs/{id}', [RangController::class, 'show']);
    Route::post('rangs', [RangController::class, 'store']);

    //Route::put('rangs/{id}', [RangController::class, 'update']);
     Route::post('rangs/{id}', [RangController::class, 'update']);
    Route::post('rangs/{id}/delete', [RangController::class, 'destroy']);

    //Route::delete('rangs/{id}', [RangController::class, 'destroy']);

//branches
    Route::get('/get/one/branch/{branchId}' , [BranchController::class , 'getbranch']);
    Route::get('/get/branch', [BranchController::class, 'index']);
    Route::post('/create/branch', [BranchController::class,'store']);
//    Route::put('/update/branch/{id}', [BranchController::class, 'update']);
Route::post('/branches/{id}', [BranchController::class, 'update']);
Route::post('/delete/branch/{id}', [BranchController::class, 'destroy']);
//    Route::delete('/delete/branch/{id}', [BranchController::class,'destroy']);
Route::get('getOrderstatus' , [OrderStatusController::class , 'getOrderTrackingStatus']);


//Route::post('/send-fcm-notification', 'FcmNotificationController@sendNotification');


